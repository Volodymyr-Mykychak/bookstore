package com.store.book.dto;

public record BookSearchParametersDto(String[] title, String[] author, String[] isbn) {

}
